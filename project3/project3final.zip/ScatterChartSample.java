package som;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
 
 
/**
 * Class used to represent the data for the travelling sales man problem
 * 
 */
public class ScatterChartSample extends Application {
 
	ScatterChart<Number,Number> sc;
	XYChart.Series series1 = new XYChart.Series();
	
	XYChart.Series series2 = new XYChart.Series();
	
	
    @Override public void start(Stage stage) throws IOException {
        stage.setTitle("Scatter Chart Sample");
        BufferedReader br = new BufferedReader(new FileReader("C:/Users/Stefan/Desktop/endq.txt"));
        String mapName = br.readLine();
        String[] dim = br.readLine().split(";");
        double lowX = Double.parseDouble(dim[0]);
        double lowY = Double.parseDouble(dim[2]);
        DecimalFormat df = new DecimalFormat("#.###");
        df.setRoundingMode(RoundingMode.HALF_UP);
        System.out.println(lowX);
        lowX = Double.parseDouble(df.format(lowX));
        lowY = Double.parseDouble(df.format(lowY));
        System.out.println(lowX);
        final NumberAxis xAxis = new NumberAxis(Double.parseDouble(dim[0])-0.001, Double.parseDouble(dim[1])+.001, .01);
        final NumberAxis yAxis = new NumberAxis(Double.parseDouble(dim[2])-.001, Double.parseDouble(dim[3])+.001, .01);
        
        final LineChart<Number,Number> sc = new LineChart<>(xAxis,yAxis);
        xAxis.setLabel("x-coordinate");                
        yAxis.setLabel("y-coordinate");
        sc.setTitle(mapName);
        
        XYChart.Series series1 = new XYChart.Series();
        String length = br.readLine();
        int iterations = Integer.parseInt(length);
        for (int i = 0; i < iterations; i++) {
			String[] coordinates = br.readLine().split(";");
			series1.getData().add(new XYChart.Data(Double.parseDouble(coordinates[0]), Double.parseDouble(coordinates[1])));
		}
        length = br.readLine();
        iterations = Integer.parseInt(length);
        
        XYChart.Series series2 = new XYChart.Series();
        String[] first = null;
        String[] last = null;
        for (int i = 0; i < iterations; i++) {
        	String[] coordinates = br.readLine().split(";");
			series2.getData().add(new XYChart.Data(Double.parseDouble(coordinates[0]), Double.parseDouble(coordinates[1])));
			if (i == 0) {
				 first = coordinates;
			}
			if(i == iterations-1) {
				last = coordinates;
			}
		}
        XYChart.Series series3 = new XYChart.Series();
        series3.getData().add(new XYChart.Data(Double.parseDouble(last[0]), Double.parseDouble(last[1])));
        series3.getData().add(new XYChart.Data(Double.parseDouble(first[0]), Double.parseDouble(first[1])));
        System.out.println(series1.getData().size());
        System.out.println(series2.getData().size());
        br.close();
        sc.setAnimated(false);
        
        sc.getStyleClass().add("thick-chart");
        sc.setCreateSymbols(true);
        sc.setAxisSortingPolicy(LineChart.SortingPolicy.NONE);
        sc.getData().addAll(series1,series2,series3);
        Scene scene  = new Scene(sc, 500, 400);
        scene.getStylesheets().add(getClass().getResource("scatterchart.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
    
    public ScatterChartSample() {
    	
    }
   
 
    public static void main(String[] args) {
        launch(args);
    }
}