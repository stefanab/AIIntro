package som;

/**
 * @author Stefan
 * 
 * Help class for SOMTravelingSalesMan. Stores the node data
 */
public class DynamicNodePoint extends NodePoint {

	NodePoint bestCity;
	double distance;
	
	public NodePoint getBestCity() {
		return bestCity;
	}

	public void setBestCity(NodePoint bestCity) {
		this.bestCity = bestCity;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	DynamicNodePoint(double x, double y) {
		super(x, y);
		distance = Double.MAX_VALUE;
		
		// TODO Auto-generated constructor stub
	}

}
