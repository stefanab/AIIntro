package som;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

import nqueens.Board;

/**
 * @author Stefan
 *
 */
public class SOMTravelingSalesMan {

	
	
	private static final int NUMBER_OF_ITERATIONS =10000000;					//Number of iterations before stop
	private static final double A = 1;											//Constant in neighborhood function
	private static final double B = 0;											//Constant in neighborhood function
	private static final double C = 1;											//Constant in neighborhood function
	private static final double LINEAR_LEARNING_DECAY = 0.000001;				//Decay at each step (linear learning)
	private static final double LINEAR_NEIGHBORHOOD_DECAY = 0.0001;				//Decay at each step (linear neighborhood)
	private static final double EXPONENTIAL_LEARNING_DECAY = 0.99999995;		//Decay at each step (exponential learning)
	private static final double EXPONENTIAL_NEIGHBORHOOD_DECAY = 0.99999995;	//Decay at each step (exponential neighborhood)
	int times = 0;																//Times the coordinates are scaled used to convert back to km at the end
	private char learningRateType;												//Learning rate decay type chosen by user
	private char neighbourhoodDecayType;										//Neighborhood decay type chosen by user
	private double neighborhoodSize;											//Neighborhood size set to 1/10 of total nodes 
	private double learningRate = 0.9;											//Initial learning rate
	LinkedList<NodePoint> shortestPath = new LinkedList<NodePoint>();			//Shortest path found so far as a list of cities
	double shortestPathLength = Double.MAX_VALUE;								//Value of shortest path
	LinkedList<DynamicNodePoint> nodes = new LinkedList<DynamicNodePoint>();	//Nodes in the elastic circle
	ArrayList<NodePoint> cities = new ArrayList<NodePoint>();					//Initial cities given by user input
	static int NUMBER_OF_NODES = 4;											//Number of additional nodes. Total nodes given by: cities(size) + NUMBER_OF_NODES

	public SOMTravelingSalesMan(char learningRateDecayType, char neighbourhoodDecayType, ArrayList<NodePoint> cities, double lowestX, double highestX, double lowestY, double highestY) {
		this.learningRateType = learningRateDecayType;
		this.neighbourhoodDecayType = neighbourhoodDecayType;
		this.cities = cities;
		//initiate random nodes
		Random rdm = new Random();
		for (int i = 0; i < cities.size()+NUMBER_OF_NODES; i++) {
			double x = lowestX + (highestX - lowestX) * rdm.nextDouble();
			double y = lowestY + (highestY - lowestY) * rdm.nextDouble();
			nodes.add(new DynamicNodePoint(x, y));
		}
		this.neighborhoodSize = (nodes.size()/10.0);
	}
	
	
	/**
	 * Divides by 10 until the city coordinates lies between 0 and 1
	 * 
	 * @param city		NodePoint a city with coordinates
	 * @return			NodePoint a city with coordinates between 0 and 1
	 */
	public static NodePoint normalize(NodePoint city) {
		
		while((city.getX() > 1) || city.getY() > 1) {
			city.setX(city.getX()/10.0);
			city.setY(city.getY()/10.0);
		}
		
		return city;
	}
	
	
	/**
	 * Finds the best matching unit (node) for the city input. By calculating the Euclidean distance for each node
	 * 
	 * @param city			NodePoint a city for which to find the BMU
	 * @return				int position of the BMU from nodes
	 */
	public int findBMU(NodePoint city) {
		double bestDistance = Double.MAX_VALUE;
		
		int bestIndex=0;
		for (int i = 0; i < this.nodes.size(); i++) {
			double distance = calculateDistance(city, nodes.get(i));
			if(distance < nodes.get(i).getDistance()){
				nodes.get(i).setBestCity(city);
				nodes.get(i).setDistance(distance);
			}
			if (distance < bestDistance) {
				bestDistance = distance;
				bestIndex = i;
			}
		}
		city.setClosestNodeIndex(bestIndex);
		return bestIndex;
	}
	
	/**
	 * Calculates the euclidean distance from input city to input node
	 * 
	 * @param city			NodePoint city to calculate distance from
	 * @param node			DynamicNodePoint node to calculate distance from
	 * @return				double distance from city to node
	 */
	public double calculateDistance(NodePoint city, DynamicNodePoint node) {
		return Math.sqrt((Math.pow((city.getX()-node.getX()),2)) + (Math.pow((city.getY()-node.getY()),2)));
		
	}
	
	/**
	 * Finds a path which might be the current shortest path. 
	 * 
	 * @return 		double length of the path
	 */
	private double findPath() {
		LinkedList<NodePoint> sortedCities = sortCities();
		double pathLength = 0;
		for (int i = 1; i < sortedCities.size(); i++) {
			double pathX = sortedCities.get(i-1).getX()-sortedCities.get(i).getX();
			double pathY = sortedCities.get(i-1).getY()-sortedCities.get(i).getY();
			pathLength += Math.sqrt(pathX*pathX + pathY*pathY);
		}
		double pathX = sortedCities.get(sortedCities.size()-1).getX()-sortedCities.get(0).getX();
		double pathY = sortedCities.get(sortedCities.size()-1).getY()-sortedCities.get(0).getY();
		pathLength += Math.sqrt(pathX*pathX + pathY*pathY);
		if (pathLength < shortestPathLength){
			shortestPathLength = pathLength;
			shortestPath = sortedCities;
		}
		return pathLength;
	}

	/**
	 * Sorts cities based on position in the node circle so that the shortest path can be found. Cities connected to the same node are sorted randomly
	 * 
	 * @return		LinkedList<NodePoint> list with the sorted cities
	 */
	private LinkedList<NodePoint> sortCities() {
		LinkedList<NodePoint> sortedCities = new LinkedList<NodePoint>();
		sortedCities.add(this.cities.get(0));
		for (int i = 1; i < cities.size(); i++) {
			
			int nextCityNodeIndexToSort = cities.get(i).getClosestNodeIndex();
			int consideredInsertCities = sortedCities.size();
			int startIndex = 0;
			while(consideredInsertCities > 1) {
				int correctionIndex = Math.floorMod(consideredInsertCities, 2);
				consideredInsertCities = Math.floorDiv(consideredInsertCities, 2);
				NodePoint consideredCity = sortedCities.get(consideredInsertCities+startIndex);
				
				if (nextCityNodeIndexToSort > consideredCity.getClosestNodeIndex()) {
					
				} else {
					startIndex += consideredInsertCities+ correctionIndex;
				}
			}
			if (sortedCities.get(startIndex).getClosestNodeIndex() < nextCityNodeIndexToSort) {
					sortedCities.add(startIndex, cities.get(i));
			} else {
				double prob = 1;
				if (sortedCities.get(startIndex).getClosestNodeIndex() == nextCityNodeIndexToSort){
					Random rdm = new Random();
					prob = rdm.nextDouble();
				}
				
				if(startIndex == sortedCities.size()-1) {
					if(prob > 0.5) {
						sortedCities.add(cities.get(i));
					} else {
						sortedCities.add(startIndex,cities.get(i));
					}
				} else {
					if ( prob > 0.5) {
						sortedCities.add(startIndex+1, cities.get(i));
					} else {
						sortedCities.add(startIndex,cities.get(i));
					}
				}
			}
		}
	return sortedCities;
	}

	/**
	 * Deacreases the learning rate based on initial input
	 * 
	 */
	private void decreaseLearningRate() {
		// TODO Auto-generated method stub
		switch (learningRateType) {
		case 's':
			
			break;
		
		case 'l':
				this.learningRate = this.learningRate - LINEAR_LEARNING_DECAY;
				if (this.learningRate <= 0) {
					this.learningRate = 0;
				}
			break;
			
		case 'e':
				this.learningRate = this.learningRate * EXPONENTIAL_LEARNING_DECAY;
			break;
		default:
			break;
		}
	}



	/**
	 * Deacreses neighborhoodSize based on initial input
	 */
	private void decreaseNeighborHood() {
		// TODO Auto-generated method stub
		switch (neighbourhoodDecayType) {
		case 's':
			
			break;
		
		case 'l':
			this.neighborhoodSize = this.neighborhoodSize - LINEAR_NEIGHBORHOOD_DECAY;	
			if (this.neighborhoodSize <= 0) {
				this.neighborhoodSize = 0;
			}
			break;
			
		case 'e':
			this.neighborhoodSize = this.neighborhoodSize * EXPONENTIAL_NEIGHBORHOOD_DECAY;
			break;
		default:
			break;
		}
		
	}

	/**
	 * Updates the neighborhood of the BMU.
	 * 
	 * @param bmuIndex		int position of BMU in nodes
	 * @param city			NodePoint city which to connect the BMU to
	 */
	private void UpdateNeighborhood(int bmuIndex, NodePoint city) {
		
		updateNode(bmuIndex,city,1.0);
		for (int i = 1; i < Math.round(neighborhoodSize); i++) {
			int leftNeighbor = bmuIndex-i;
			if(leftNeighbor<0) {
				leftNeighbor = nodes.size()+leftNeighbor;
			}
			int rightNeighbor = bmuIndex+i;
			if(rightNeighbor>=nodes.size()){
				rightNeighbor=0+ rightNeighbor - nodes.size();
			}
			double neighborWeight = neighborhoodFunction(i);
			updateNode(leftNeighbor, city, neighborWeight);
			updateNode(rightNeighbor, city, neighborWeight);
		}
		
	}
	

	/**
	 * Updates the input node.
	 * 
	 * @param bmuIndex			int index of the node in nodes to update
	 * @param city				NodePoint city to calculate distance from
	 * @param neighborWeight	double weighting of the node to be updated based on distance from he BMU
	 */
	private void updateNode(int bmuIndex, NodePoint city, double neighborWeight) {
		// TODO Auto-generated method stub
		DynamicNodePoint bmu = nodes.get(bmuIndex);
		bmu.setX(bmu.getX()+neighborWeight*learningRate*(city.getX()-bmu.getX()));
		bmu.setY(bmu.getY()+neighborWeight*learningRate*(city.getY()-bmu.getY()));
	}

	/**
	 * Nieghborhood function used to calculate the weighting of nodes when they are updated. Gaussian function is used.
	 * 
	 * @param i		int length of the considered node to the BMU
	 * @return		double weighting value between 0 and 1
	 */
	private double neighborhoodFunction(int i) {
		double topSide = Math.pow((double) i-B,(double) 2);
		double botSide = Math.pow((double) 2*C,(double) 2);
		double value = A * Math.exp(-(topSide/botSide));
		if (value > 1) {
			value = 1;
		}
		return value;
		
	}
	
	public static void main(String[] args) throws IOException {
		
		//Initiate algorithm with input from user
		
		Scanner sc = new Scanner(System.in);
		ArrayList<NodePoint> cities = new ArrayList<NodePoint>();
		System.out.println("Insert map name");
		String map = sc.next();
		System.out.println("Insert learning rate decay type, static (s), linear(l), exponential(e):");
		String learningratedecay = sc.next();
		System.out.println("Insert neighborhood decay type, static (s), linear(l), exponential(e):");
		String neighborhooddecay = sc.next();
		System.out.println("Calculate distance every k steps, k:");
		String ksteps = sc.next();
		String map1;
		String mapName;
		sc.close();
		switch (map) {
		case "d":
			map1 = "dj38";
			mapName = "Djibouti";
			break;
		case "ws":
			map1 = "wi29";
			mapName = "Western-Sahara";
			break;
		case "q":
			map1 = "qa194";
			mapName = "Qatar";
			break;
		case "u":
			map1 = "uy734";
			mapName = "Uruguay";
			break;
		default:
			map1 = "dj38";
			mapName = "Djibouti";
			break;
		}
		
		//Fetch country data from website
		
		URL datalocation = new URL("http://www.math.uwaterloo.ca/tsp/world/" + map1 + ".tsp");
        URLConnection yc = datalocation.openConnection();
        BufferedReader in = new BufferedReader(
        		new InputStreamReader(yc.getInputStream()));

        String inputLine;
        inputLine = in.readLine();
        while (!inputLine.equals("NODE_COORD_SECTION")){
        	inputLine = in.readLine();
        }
        inputLine = in.readLine();
        double lowestX = 1.0;
        double highestX = 0.0;
        double lowestY = 1.0;
        double highestY = 0.0;
        boolean overMid = false;
        int times = 0;
        int kcalc = Integer.parseInt(ksteps);
        int k = 0;
        double shortestPathLength = Double.MAX_VALUE;
        while ((inputLine != null) && (!inputLine.equals("EOF"))) {
		
			String[] parsed = inputLine.split(" ");
			
			NodePoint city = normalize(new NodePoint(Double.parseDouble(parsed[1]), Double.parseDouble(parsed[2])));
			int scale =  (int) ((int) Double.parseDouble(parsed[1])/city.getX());
			if(scale > times) {
				times = scale;
			}
			if (city.getX() < lowestX) {
				lowestX = city.getX(); 
			}
			if (city.getX() > highestX) {
				highestX = city.getX(); 
			}
			if (city.getY() < lowestY) {
				lowestY = city.getY(); 
			}
			if (city.getY() > highestY) {
				highestY = city.getY(); 
			}
			cities.add(city);
			inputLine = in.readLine();
			
		}
       // initiate algorithm instance and save initial node and city data
		SOMTravelingSalesMan tsm = new SOMTravelingSalesMan(learningratedecay.charAt(0), neighborhooddecay.charAt(0), cities,lowestX,highestX,lowestY,highestY);
		
		PrintWriter writer = new PrintWriter("C:/Users/Stefan/Desktop/start"+map+".txt", "UTF-8");
		writer.println(mapName);
		writer.println(lowestX+";"+highestX+";"+lowestY+";"+highestY);
		writer.println(tsm.cities.size() + "");
		for (NodePoint city : cities) {
			writer.println(city.getX() + ";" + city.getY());
		}
		writer.println(tsm.nodes.size() +"");
		for (NodePoint node : tsm.nodes) {
			writer.println(node.getX() + ";" + node.getY());
		}
		writer.close();
		Random rdm = new Random();
		//algorithm start
		for (int i = 0; i < NUMBER_OF_ITERATIONS; i++) {
			//Pick next city 
			int nextCityIndex = rdm.nextInt(cities.size());
			NodePoint city = tsm.cities.get(nextCityIndex);
				 int bmuIndex = tsm.findBMU(city);
				 tsm.UpdateNeighborhood(bmuIndex, city);
				 tsm.decreaseNeighborHood();
				 tsm.decreaseLearningRate();
			//compute shortest path so far
			if (i == kcalc*k) {
				k++;
				for (NodePoint city2 : cities) {
					tsm.findBMU(city2);
				}
				double pathLength = tsm.findPath();
				if (pathLength < shortestPathLength) {
					shortestPathLength = pathLength;
				}
				System.out.println("Shortest path after iteration " + i + ": " + tsm.shortestPathLength);
				System.out.println("LR: " + tsm.learningRate);
				System.out.println("NH: " + tsm.neighborhoodSize);
				System.out.println();
			}
			
			//Save half-way data for visual representation
			if(i >= NUMBER_OF_ITERATIONS/2 && !overMid) {
				overMid = true;
				writer = new PrintWriter("C:/Users/Stefan/Desktop/mid"+map+".txt", "UTF-8");
				writer.println(mapName);
				writer.println(lowestX+";"+highestX+";"+lowestY+";"+highestY);
				writer.println(tsm.cities.size() + "");
				for (NodePoint city1 : cities) {
					writer.println(city1.getX() + ";" + city1.getY());
				}
				writer.println(tsm.nodes.size() +"");
				for (NodePoint node : tsm.nodes) {
					writer.println(node.getX() + ";" + node.getY());
				}
				writer.close();
			}
			
		}
		//Save end data for visual representation
		System.out.println(tsm.shortestPathLength*times);
		writer = new PrintWriter("C:/Users/Stefan/Desktop/end"+map+".txt", "UTF-8");
		writer.println(mapName);
		writer.println(lowestX+";"+highestX+";"+lowestY+";"+highestY);
		writer.println(tsm.cities.size() + "");
		for (NodePoint city : cities) {
			writer.println(city.getX() + ";" + city.getY());
		}
		writer.println(tsm.nodes.size() +"");
		
		for (NodePoint node : tsm.nodes) {
			writer.println(node.getX() + ";" + node.getY());
		}
		writer.close();
		System.out.println("done");
	}
	
	

	

	
}
