package som;

/**
 * @author Stefan
 *
 *	Help class for SOMTravelingSalesMan. Stores the cities representation
 */
public class NodePoint {

	double x;
	double y;
	int closestNodeIndex;
	
	public int getClosestNodeIndex() {
		return closestNodeIndex;
	}


	public void setClosestNodeIndex(int closestNode) {
		this.closestNodeIndex = closestNode;
	}


	NodePoint(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	
	@Override
	public String toString() {
		
		return getClosestNodeIndex() + "";
	}


	public double getX() {
		return x;
	}


	public void setX(double x) {
		this.x = x;
	}


	public double getY() {
		return y;
	}


	public void setY(double y) {
		this.y = y;
	}
}
