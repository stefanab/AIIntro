package nqueens;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class NqueenSimulatedAnnealing {
	
	static int COUNT_RESET =10000;														// Iterations before reseting the algorithm
	static int T_STABALIZIER = 1;														// Iterations per stage before reducing temperature
	static double DELTA_POWER = 3;														// Power of which to raise delta. Used to punish bad solutions
	static double T_START = 10;															// Temperature at start
	static double TEMPERATURE_SCALE = 0.9;												// Scale factor for reducing temperature
	static int SOLUTIONS_BEFORE_STOP = 10000;											// Unique solutions found before termination 
	ArrayList<Integer> attacksOnQueen = new ArrayList<Integer>();						// Number of attacks on queen in each column of the current board
	ArrayList<Integer> board = new ArrayList<Integer>();								// Current board positions
	private ArrayList<Integer> initialBoard;											// Initial board. Used for reseting the algorithm
	ArrayList<ArrayList<Integer>> solutions = new ArrayList<ArrayList<Integer>>();		// List of unique solutions
	int n;																				// Size of board
	int value;																			// Value of current board
	int bestValue = Integer.MAX_VALUE;													// Best value found during current algorithm iteration
	int numberOfSolutions;																// Number of solutions found
	
	public NqueenSimulatedAnnealing(ArrayList<Integer> board) {
		this.n = board.size();
		this.initialBoard = new ArrayList<Integer>();
		for (Integer queen : board) {
			initialBoard.add(queen);
			attacksOnQueen.add(null);
		}
		this.board = generateEquilibriumBoard(board);
		value = Integer.MAX_VALUE;
	}
	
	/**
	 * Puts one queen in each row so generateNeighbour() will work properly
	 * 
	 * @param board 		arrayList<Integer> with queen placements. Can have multiple instances of same integers
	 * @return				arrayList<Integer> with queen placements. No instances of same integers
	 */
	private ArrayList<Integer> generateEquilibriumBoard(ArrayList<Integer> board) {
		ArrayList<String> rowsNotQueened = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			int row = i + 1;
			rowsNotQueened.add(row +"");
		}
		for (int i = 0; i < n; i++) {
			
			String row = board.get(i) + "";
			if(rowsNotQueened.contains(row)) {
				rowsNotQueened.remove(row);
			} else {
				Random rdm = new Random();
				int placeInRow = rdm.nextInt(rowsNotQueened.size());
				row = rowsNotQueened.get(placeInRow);
				board.set(i, Integer.parseInt(row));
				rowsNotQueened.remove(row);
			}
			
		}

		return board;
	}

	

	/**
	 *	Resets the algorithm back to initial input and resets variables. 
	 */
	public void resetBoard() {
		ArrayList<Integer> newBoard = new ArrayList<Integer>();
		for (Integer queen : this.initialBoard) {
			newBoard.add(queen);
		}
		newBoard = generateEquilibriumBoard(newBoard);
		value = calculateValue(newBoard);
		bestValue = Integer.MAX_VALUE;
		setBoard(newBoard,value);
		
		
	}

	/**
	 * Generates a neighbour to the current board by switching the positions of two random queens
	 * 
	 * @return 		ArrayList<Integer> a new board. Each queen in a unique row and col
	 */
	private ArrayList<Integer> generateNeighbour() {
		ArrayList<Integer> neighbour = new ArrayList<Integer>();
		Random rdm = new Random();
		int col1=0;
		for (Integer queen : board) {
			neighbour.add(queen);
		}
		// if there is only one attack pick this queen and try all places to find solution
		if (value == 1) {
			for (int i = 0; i < n; i++) {
				if (attacksOnQueen.get(i) == 1) {
					col1 = i;
				}
			}
			for (int i = 0; i < n-1; i++) {
				if(i != col1) {
					int row1 = neighbour.get(col1);
					int row2 = neighbour.get(i);
					neighbour.set(col1, row2);
					neighbour.set(i, row1);
					int neighbourValue = calculateValue(neighbour);
					if(neighbourValue == 0) {
						return neighbour;
					} else {
						neighbour.set(col1, row1);
						neighbour.set(i, row2);
					}
				}
			}
		} 
			
			col1 = rdm.nextInt(n);
			boolean switchColFound = false;
			while(!switchColFound) {
				int col2 = rdm.nextInt(n);
				if (col1 != col2) {
					int row1 = neighbour.get(col1);
					int row2 = neighbour.get(col2);
					neighbour.set(col1, row2);
					neighbour.set(col2, row1);
					return neighbour;
				}
			}
		
		return null;
	}

	/**
	 * Update current state 
	 * 
	 * @param newBoard		ArrayList<Integer> board to be set as current board
	 * @param value			int value of the board to be set as current board
	 */
	private void setBoard(ArrayList<Integer> newBoard, int value) {
		this.board = newBoard;
		setValue(value);
	}

	private void setValue(int value) {
		this.value = value;
	}

	/**
	 * Adds current board to solutions
	 */
	private void AddSolution() {
		solutions.add(board);
		printSolution();
	}
	
	/**
	 * Prints the current positions on the board
	 */
	public void printSolution() {
		String solution = "";
		for (Integer queen : board) {
			solution += queen + " ";
		}
	System.out.println(solution);
	}

	/**
	 * Check whether current solution has been found previously
	 * 
	 * @return		boolean, true of current solution is unique. False if current solution is not unique
	 */
	private boolean checkForUniqueSolution() {
			if (!this.solutions.contains(this.board)) {
				return true;
			}
		return false;
	}

	private int getValue() {
		return this.value;
	}

	/**
	 * Calculates the fitness value of a board. The value is the sum of all attacks on each queen
	 * 
	 * @param nextBoard		arrayList<Integer board on which to calculate fitness 	
	 * @return				int value of fitness. Lower value equals higher fitness. Value = 0 is a solution
	 */
	private int calculateValue(ArrayList<Integer> nextBoard) {
		//count number of attacking queens. The higher value the worse the position on the table is
		int attacks = 0; 
		for (int i = 0; i < nextBoard.size(); i++) {
			int attacksOnQueenI = countAttacksForQueenIn(nextBoard.get(i), i+1, nextBoard);
			attacksOnQueen.set(i, attacksOnQueenI);
			attacks += attacksOnQueenI;
		}
		
		return attacks;
	}
	
	/**
	 * Help function for calculateValue(). Calculates attacks on queen in row, row, and col, col, in board, nextBoard
	 * 
	 * @param row			int queen row
	 * @param col			int queen col
	 * @param nextBoard		arrayList<Integer board under evaluation
	 * @return				int number of attacks on queen in column, col, for column, c, c < col
	 */
	private int countAttacksForQueenIn(int row, int col, ArrayList<Integer> nextBoard) {
		int attacks = 0;
		//check earlier cols for horisontal collision
		for (int i = 1; i < col; i++) {
			if (nextBoard.get(i-1).equals(row)) {
				attacks++;
			}
		}
		//check earlier cols for diagonal (down) collision
		for (int i = col-1; i >= 1; i--)  {
			int thisRow = row+i-col;
			//check if row still on board
			//check if queen in earlier column is on the same diagonal
			if (nextBoard.get(i-1) == thisRow ) {
				attacks++;
			}
			if (thisRow < 1) {
				break;
			}
		}
		
		//check earlier cols for diagonal (up) collision
		for (int i = col-1; i >= 1; i--) {
			int thisRow = row-i+col;
			//check if row still on board
			if (nextBoard.get(i-1) == thisRow) {
				attacks++;
			}
			if (thisRow > n) {
				break;
			}
			//check if queen in earlier column is on the same diagonal
		}
		
		return attacks;
	}
	
	public static void main(String[] args) {
		int iterations = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("size of board: ");
		int n = sc.nextInt();
		sc.nextLine();
		System.out.println("insert queen string");
		String[] board = sc.nextLine().split(" ");
		ArrayList<Integer> intBoard = new ArrayList<Integer>();
		for (String string : board) {
			intBoard.add(Integer.parseInt(string));
		}
		sc.close();
		if ((intBoard.size() != n) || intBoard.size() < 4) {
			throw new IllegalArgumentException("Wrong board size!");
		}
		
		//initialze algorithm
		NqueenSimulatedAnnealing sa = new NqueenSimulatedAnnealing(intBoard);
		int value = sa.calculateValue(intBoard);
		sa.setValue(value);
		int numberOfSolutions = 0;
		double T = T_START;
		double stabCount = 0;
		iterations = 0;
		int worseAccpeted = 0;
		long startTime = System.nanoTime()/ 1000000;
		System.out.println(System.nanoTime()/ 1000000);
		//Algorithm start
		while (numberOfSolutions < SOLUTIONS_BEFORE_STOP) {
			iterations++;
			
			//check first if we have a new, unique solution and if so add it to the rest for later comparison
			if (sa.getValue() == 0) {
				System.out.println("Found a Solution!");
				if(sa.checkForUniqueSolution()) {
					numberOfSolutions++;
					System.out.println("and it was a new one! Number: " + numberOfSolutions);
					System.out.println("Iterations: " +iterations);
					System.out.println("Worse accpeted: " + worseAccpeted);
					sa.AddSolution();
					
				}
				worseAccpeted = 0;
				iterations = 0;
				stabCount = 0;
				sa.resetBoard();
				T = T_START;
			}
			//generate new neighbours (randomly) and calculate their objective function/value
			ArrayList<Integer> nextBoard = sa.generateNeighbour();
			int nextValue = sa.calculateValue(nextBoard);
			
			//if new solution is better, take it as the next solution
			if (nextValue <= sa.getValue()) {
				if(nextValue < sa.bestValue) {
					sa.bestValue = nextValue;
				} 
				sa.setBoard(nextBoard, nextValue);
				
			} 
			
			//if its not better take it as next solution with a probability of:
			else {
				double delta = (nextValue-sa.getValue());
				double prob = Math.exp(-((delta)/T));
				
				double rdm = Math.random();
				if (prob > rdm) {
					sa.setBoard(nextBoard, nextValue);
					worseAccpeted++;
				}
			}
			//reduce temperature
			if (T_STABALIZIER <= stabCount) {
				T = T * TEMPERATURE_SCALE;
				stabCount = 0;
			}
			
			//reset algorithm if solution not found in COUNT_RESET iterations
			if(iterations >= COUNT_RESET) {
				System.out.println("failed");
				System.out.println("best value: " + sa.bestValue);
				System.out.println("Temp: " + T);
				sa.resetBoard();
				T = T_START;
				iterations = 0;
			}
			stabCount++;
			if (numberOfSolutions < 1) {
				System.out.println();
				System.out.println("Best board (value " + sa.value + ") after " + iterations + " iterations: ");
				sa.printSolution();
				System.out.println("worse accepted: " + worseAccpeted);
				System.out.println();
			}
		}
		//time taken to find solution(s)
		long totalTime = (System.nanoTime()/ 1000000) - startTime;
		System.out.println(totalTime);
		iterations = 0;
	}
}
