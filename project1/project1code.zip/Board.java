package nqueens;

import java.util.ArrayList;

/**
 * @author Stefan Sobczyszyn Borg
 *
 * Help class for NqueenGeneticAlgorithm class. Keeps track of a board and its adjoining fitness value
 */
public class Board {

	private ArrayList<Integer> board = new ArrayList<Integer>();
	private int value;
	
	public Board(ArrayList<Integer> board, int value) {
		for (Integer queen : board) {
			this.board.add(queen);
		}
		this.value = value;
	}

	public ArrayList<Integer> getBoard() {
		return board;
	}

	public void setBoard(ArrayList<Integer> board) {
		this.board = board;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
//		String str = "[";
//		for (Integer integer : board) {
//			str += integer + ", ";
//		}
//		str = str.substring(0, str.length()-2);
		return board + "";
	}
}
