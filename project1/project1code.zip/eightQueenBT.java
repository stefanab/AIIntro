package nqueens;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Stefan Sobczyszyn Borg
 *
 */
public class eightQueenBT {

	
	
	
	
	
	private ArrayList<Integer> initialBoard; // intialBoard 	Initial board is given by input. Used for comparing if queen placement is given
	private ArrayList<Integer> board; 		 // board 			The board as of current iteration
	int nrOfSolutions; 						 // nrOfSolutions	Counter for number of solutions found
	boolean collide = false;				 // collide			Boolean used for printing step-by-step solution correct
	
	
	/** 
	 * @param intQueens 		An arrayList<Integer> with initial board position
	 */
	public eightQueenBT(ArrayList<Integer> intQueens) {
		this.board = intQueens;
		this.initialBoard = new ArrayList<Integer>();
		for (Integer queen : intQueens) {
			initialBoard.add(queen);
		}
		nrOfSolutions = 0;
	}

	
	
	/**
	 * Prints the current position of the board
	 */
	public void printSolution() {
		String solution = "";
		for (Integer queen : board) {
			solution += queen + " ";
		}
	System.out.println(solution);
	}

	
	/**
	 * @param col  		column from which to start the backtrack and insert next queen
	 * @return 			boolean, whether queen can be inserted (true) or insert creates an invalid solution (false)  
	 */
	private boolean findSolution( int col) {
		while (nrOfSolutions < 1) {
		if (col > 8) {
			printSolution();
			nrOfSolutions++;
			return false;
		}
		//check starting conditions for explicit queen placement
		if (initialBoard.get(col-1) != 0) {
			if(!checkInsertisGood(this.board.get(col-1),col)) {
				System.out.println("Starting conditions collide in col " + col);
				collide = true;
				return false;
			}
			System.out.println("Starting condition in col " + col + ": OK");
			col++;
			if (findSolution( col) == true){
				return true;
			}
		}
		//queen has no initial constraint on placement
		else {
			System.out.println("try inserting queen in col " + col);
				for (int i = 1; i <= 8; i++) {
					if (checkInsertisGood(i,col)) {
						this.board.set(col-1, i);
						if(nrOfSolutions == 0) {
							System.out.println("row " + i + " worked");
							printSolution();
						}
						col++;
						if(findSolution( col)) {
							return true;
						//backtrack	
						} else {			
							col--;		
						}
					}
				}
			}
		//no solution possible for current positions
		// reset board for visual effect
		this.board.set(col-1, 0);
		if(nrOfSolutions == 0 && collide == false) {
			int bt = col-1;
			System.out.println("backtracking to col " + bt );
			printSolution();
		}
		return false;
		}
		return false;
	}

	/**
	 * Checks if the insert of a queen in column, col, and row, row, collides with any queen in previous columns c, c < col
	 * 
	 * @param row 		int row in which the queen should be placed
	 * @param col		int col in which the queen should be placed
	 * @return			boolean, true if valid placement, false if a collision is detected
	 */
	private boolean checkInsertisGood(int row, int col) {
		//check earlier cols for horisontal collision
		for (int i = 1; i < col; i++) {
			if (board.get(i-1).equals(row)) {
				return false;
			}
		}
		//check earlier cols for diagonal (up) collision
		for (int i = col-1; i >= 1; i--)  {
			int thisRow = row+i-col;
			//check if row still on board
			if (thisRow < 1) {
				break;
			}
			//check if queen in earlier column is on the same diagonal
			if (board.get(i-1) == thisRow ) {
				return false;
			}
		}
		
		//check earlier cols for diagonal (down) collision
		for (int i = col-1; i >= 1; i--) {
			int thisRow = row-i+col;
			//check if row still on board
			if (thisRow > 8) {
				break;
			}
			//check if queen in earlier column is on the same diagonal
			if (board.get(i-1) == thisRow) {
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("insert queen string");
		String[] board = sc.nextLine().split(" ");
		ArrayList<Integer> intBoard = new ArrayList<Integer>();
		for (String string : board) {
			intBoard.add(Integer.parseInt(string));
		}
		eightQueenBT eqbt = new eightQueenBT(intBoard);
		
		//start algorithm from column 1
		eqbt.findSolution( 1);
		
			if( eqbt.nrOfSolutions == 0) {
				System.out.println("no solution with given input");
			}
		System.out.println("Number of solutions: " + eqbt.nrOfSolutions);
		sc.close();
	}

}
