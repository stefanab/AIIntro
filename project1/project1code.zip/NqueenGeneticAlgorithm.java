package nqueens;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;


/**
 * @author Stefan Sobczyszyn Borg
 * Class to solve the n queen problem using a genetic algorithm approach
 */
public class NqueenGeneticAlgorithm {

	// Note to self: Best speed performance: MC =.25, PS = 5, NG = 2 IBR = 7k
	
	static double MUTATION_CHANCE = 0.25;												// Chance of a mutation to happen
	static int POPULATION_SIZE = 5;														// Population size
	static int NEXT_GENERATION_SIZE = 2;												// Next generation size
	static int SOLUTIONS_BEFORE_STOP = 5000;											// Solutions to find before termination
	static int ITERATIONS_BEFORE_RESTART = 7000;										// Iterations before reseting the algorithm
	static double ADDITIONAL_CHANCE = 1;												// Additional chance to accept a parent
	Board initialBoard;																	// Initial Board. Board position and value stored
	ArrayList<Integer> attacksOnQueen = new ArrayList<Integer>();						// List of attacks on each queen
	ArrayList<ArrayList<Integer>> solutions = new ArrayList<ArrayList<Integer>>();		// List of unique solutions
	LinkedList<Board> population = new LinkedList<Board>();								// List of current population
	int n;																				// Size of board
	int totalIterations = 0;															// Total iterations. Used for calculation avg ite before solution is found
	int numberOfSolutions;																// Number of unique solutions
	private int populationValue;														// Total value of current population
	int bestValue;																		// Best value found during current iteration of algorithm
	
	/**
	 * Initialize variables 
	 * 
	 * @param initBoard 		ArrayList<Integer> initial board positions
	 */
	public NqueenGeneticAlgorithm(ArrayList<Integer> initBoard) {
		this.n = initBoard.size();
		ArrayList<Integer >intBoard = new ArrayList<Integer>();
		for (Integer queen : initBoard) {
			intBoard.add(queen);
			attacksOnQueen.add(null);
		}
		int value = calculateValue(initBoard);
		this.initialBoard = new Board(intBoard, value);
		bestValue = Integer.MAX_VALUE;
		generateFirstPopulation(this.initialBoard);
		
	}
	
	/**
	 * Generates the primary population. Each individual is a mutation of the baseBoard, with at least one queen in the same place as in the baseBoard. 
	 * Each individual will have no queen placed in the same column or in the same row.
	 * 
	 * @param baseBoard		Board, initial input board given from user and its value
	 */
	public void generateFirstPopulation(Board baseBoard) {
		//reset population and population variables
		population.clear();
		populationValue = 0;
		bestValue = Integer.MAX_VALUE;
		// create all individuals
		for (int i = 0; i < POPULATION_SIZE; i++) {
			ArrayList<Integer> nextIndividual = new ArrayList<Integer>();
			ArrayList<String> rowsNotQueened = new ArrayList<String>();
			for (int j = 0; j < n; j++) {
				int row = j + 1;
				rowsNotQueened.add(row +"");
			}
			// assure col is not out of bounds
			int col = Math.floorMod(i, n);
			int baseRow = baseBoard.getBoard().get(col);
			rowsNotQueened.remove(baseRow + "");
			Random rdm = new Random();
			//create specific individual
			for (int k = 0; k < n; k++) {
				// make sure next individual has some common features with baseBoard
				if (k != col) {
					int nextRowIndex = rdm.nextInt(rowsNotQueened.size());
					String row = rowsNotQueened.get(nextRowIndex);
					nextIndividual.add(Integer.parseInt(row));
					rowsNotQueened.remove(row);
				} else {
					nextIndividual.add(baseRow);
				}
			}
		// update population
		int individualValue = calculateValue(nextIndividual);
		AddToPopulation(new Board(nextIndividual,individualValue), this.population);
		populationValue += individualValue;
		}
	}

	/**
	 * Adds an instance of Board to the given population. The population is sorted by value. Best value instances are at the end of the list, worst
	 * value instances at the beginning. The returned list will have ha size which is 1 greater than the size of the input list.
	 * 
	 * @param board				Board, instance to be added to population
	 * @param population		LinkedList<Board> population which to add board
	 * @return					LinkedList<Board> updated population with the Board added in its correct position
	 */
	private LinkedList<Board> AddToPopulation(Board board, LinkedList<Board> population) {
		// An empty list can not be compared
		if (population.isEmpty()) {
			population.add(board);
		} else {
			int newIndividualValue = board.getValue();
			int consideredPopulation = population.size();
			int startIndex = 0;
			while(consideredPopulation > 1) {
				int correctionIndex = Math.floorMod(consideredPopulation, 2);
				consideredPopulation = Math.floorDiv(consideredPopulation, 2);
				Board consideredBoard = population.get(consideredPopulation+startIndex);
				if (newIndividualValue > consideredBoard.getValue()) {
					
				} else {
					startIndex += consideredPopulation+ correctionIndex;
				}
			}
			if (population.get(startIndex).getValue() < newIndividualValue) {
				population.add(startIndex, board);
			} else {
				if(startIndex == population.size()-1) {
					population.add(board);
				} else {
					population.add(startIndex+1, board);
				}
			}
		}
		return population;
		
	}

	/**
	 * Calculates the fitness value of a board. The value is the sum of all attacks on each queen
	 * 
	 * @param nextBoard		arrayList<Integer board on which to calculate fitness 	
	 * @return				int value of fitness. Lower value equals higher fitness. Value = 0 is a solution
	 */
	private int calculateValue(ArrayList<Integer> nextBoard) {
		//count number of attacking queens. The higher value the worse the position on the table is
		int attacks = 0; 
		for (int i = 0; i < nextBoard.size(); i++) {
			int attacksOnQueenI = countAttacksForQueenIn(nextBoard.get(i), i+1, nextBoard);
			attacksOnQueen.set(i, attacksOnQueenI);
			attacks += attacksOnQueenI;
		}
		
		return attacks;
	}
	
	/**
	 * Help function for calculateValue(nextBoard). Calculates attacks on queen in row, row, and col, col, in board, nextBoard
	 * 
	 * @param row			int queen row
	 * @param col			int queen col
	 * @param nextBoard		arrayList<Integer board under evaluation
	 * @return				int number of attacks on queen in column, col, for column, c, c < col
	 */
	private int countAttacksForQueenIn(int row, int col, ArrayList<Integer> nextBoard) {
		int attacks = 0;
		//check earlier cols for horisontal collision
		for (int i = 1; i < col; i++) {
			if (nextBoard.get(i-1).equals(row)) {
				attacks++;
			}
		}
		//check earlier cols for diagonal (down) collision
		for (int i = col-1; i >= 1; i--)  {
			int thisRow = row+i-col;
			//check if row still on board
			//check if queen in earlier column is on the same diagonal
			if (nextBoard.get(i-1) == thisRow ) {
				attacks++;
			}
			if (thisRow < 1) {
				break;
			}
		}
		
		//check earlier cols for diagonal (up) collision
		for (int i = col-1; i >= 1; i--) {
			int thisRow = row-i+col;
			//check if row still on board
			if (nextBoard.get(i-1) == thisRow) {
				attacks++;
			}
			if (thisRow > n) {
				break;
			}
			//check if queen in earlier column is on the same diagonal
		}
		
		return attacks;
	}
	
	

	

	
	/**
	 * Adds board to solutions
	 * 
	 * @param board		ArrayList<Integer> board to be added to solutions
	 */
	private void AddSolution(ArrayList<Integer> board) {
		solutions.add(board);
		printSolution(board);
	}
	
	/**
	 * Prints the current position of the board
	 */
	public void printSolution(ArrayList<Integer> board) {
		String solution = "";
		for (Integer queen : board) {
			solution += queen + " ";
		}
	System.out.println(solution);
	}

	/**
	 * Checks if the board is a unique solution
	 * 
	 * @param board		ArrayList<Integer> a board which is a solution
	 * @return			boolean true if the solution has not been found earlier
	 */
	private boolean checkForUniqueSolution(ArrayList<Integer> board) {
			if (!this.solutions.contains(board)) {
				return true;
			}
		return false;
	}

	/**
	 * Mutates a board by switching the queen from column, col1, with the queen from column, col2
	 * 
	 * @param intChild		ArrayList<Integer> a board to be mutated
	 * @return				ArrayList<Integer> the board with a mutation
	 */
	private ArrayList<Integer> mutate(ArrayList<Integer> intChild) {
		Random rdm = new Random();
		int col1 = rdm.nextInt(n);
		boolean mutated = false;
		while(!mutated) {
			int col2 = rdm.nextInt(n);
			if (col1 != col2) {
				int row1 = intChild.get(col1);
				int row2 = intChild.get(col2);
				intChild.set(col1, row2);
				intChild.set(col2, row1);
				return intChild;
			}
		}
		return null;
	}

	/**
	 * Creates a child board from x and y using the Order1 crossover. The child will have exactly one queen in each row and exactly one queen in
	 * each column
	 * 
	 * @param x		ArrayList<Integer> board of parent x
	 * @param y		ArrayList<Integer> board of parent y
	 * @return		ArrayList<Integer> board of child. A crossover from x and y
	 */
	private ArrayList<Integer> reproduce(ArrayList<Integer> x, ArrayList<Integer> y) {
		Random rdm = new Random();
		//find which columns to use for crossover
		int crossover1 = rdm.nextInt(n);
		boolean crossover2selected = false;
		int crossover2 = 0;
		while(!crossover2selected) {
			crossover2 = rdm.nextInt(n);
			if(crossover2 != crossover1) {
				crossover2selected = true;
			}
		}
		//set the smaller int to variable crossover1
		if (crossover1 > crossover2) {
			int holder = crossover2;
			crossover2 = crossover1;
			crossover1 = holder;
		}
		//find the selected genes from x
		ArrayList<String> copyFromParent1 = new ArrayList<String>();
		for (int i = crossover1; i < crossover2; i++) {
			copyFromParent1.add(x.get(i)+ "");
		}
		//find the selected genes from y
		ArrayList<String> copyFromParent2 = new ArrayList<String>();
		for (int i = 0; i < y.size(); i++) {
			String parentY = y.get(i) + "";
			if(!copyFromParent1.contains(parentY)) {
				copyFromParent2.add(parentY);
			}
			
		}
		//create child based on parents
		ArrayList<Integer> child = new ArrayList<Integer>();
		int parent2index = 0;
		for (int i = 0; i < n; i++) {
			if (i >= crossover1 && i < crossover2) {
				child.add(x.get(i));
			} else {
				child.add(Integer.parseInt(copyFromParent2.get(parent2index)));
				parent2index++;
			}
		}
		return child;
	}

	/**
	 * Selects a random Board from population. Higher probability for boards with good fitness to be chosen 
	 * 
	 * @param population 	LinkedList<Board> population to chose from
	 * @return				Board a board from population
	 */
	private Board randomSelection(LinkedList<Board> population) {
		Random rdm = new Random();
		boolean acceptedParent = false;
		while (!acceptedParent) {
			int select = rdm.nextInt(population.size());
			Board consideredParent = population.get(select);
			double chance = (double) consideredParent.getValue()/populationValue;
			if(rdm.nextDouble() <  1- chance * ADDITIONAL_CHANCE) {
				return consideredParent;
			}
		}
		
		return null;
	}
	
	public static void main(String[] args) {
		
		//get input from user
		Scanner sc = new Scanner(System.in);
		System.out.println("size of board: ");
		int n = sc.nextInt();
		sc.nextLine();
		System.out.println("insert queen string");
		String[] board = sc.nextLine().split(" ");
		ArrayList<Integer> intBoard = new ArrayList<Integer>();
		for (String string : board) {
			intBoard.add(Integer.parseInt(string));
		}
		if ((intBoard.size() != n) || intBoard.size() < 4) {
			sc.close();
			throw new IllegalArgumentException("Wrong board size!");
		}
		sc.close();
		
		//initialize the algorithm
		NqueenGeneticAlgorithm ga = new NqueenGeneticAlgorithm(intBoard);
		int numberOfSolutions = 0;
		int iterations = 0;
		//algorithm start
		long startTime = System.nanoTime()/ 1000000;
		int fails = 0;
		while(numberOfSolutions < SOLUTIONS_BEFORE_STOP) {
			//check if we have a solution
			Board possibleSolution = ga.population.getLast();
			int place = 0;
			boolean solutionFound = false;
//			
			//there might be several solution in the population. So while the last individual has a fitness of 0 check for a solution
			while(possibleSolution.getValue() == 0) {
				System.out.println("found a solution");
				solutionFound = true;
				//check if solution found is unique
				if (ga.checkForUniqueSolution(possibleSolution.getBoard())) {
					ga.AddSolution(possibleSolution.getBoard());
					numberOfSolutions++;
					ga.totalIterations += iterations;
					System.out.println("it was a unique one!!" + " and it was number: " + numberOfSolutions + ". After " + iterations + " iterations");
					iterations = 0;
				}
				possibleSolution = ga.population.get(POPULATION_SIZE-place-1);
				place++;
			}
			//reset algorithm if a solution is found
			if(solutionFound) {
				ga.generateFirstPopulation(ga.initialBoard);
			}
			
			
			//create next generation
			LinkedList<Board> offspring = new LinkedList<Board>();
			for (int i = 0; i < NEXT_GENERATION_SIZE; i++) {
				//select next parents
				Board x = ga.randomSelection(ga.population);
				Board y = ga.randomSelection(ga.population);
				
				//reproduce
				ArrayList<Integer> intChild = ga.reproduce(x.getBoard(),y.getBoard());
				double mutation = Math.random();
				
				if(mutation < MUTATION_CHANCE) {
					intChild = ga.mutate(intChild);
				}
				int childValue = ga.calculateValue(intChild);
				if (childValue < ga.bestValue) {
					ga.bestValue = childValue;
				}
				
				//add new child to offspring population
				Board child = new Board(intChild, childValue);
				offspring.add(child);
			}
			
			//add next generation to main population
			for (Board child : offspring) {
				ga.AddToPopulation(child, ga.population);
				ga.populationValue += child.getValue();
			}
			
			//remove weakest individuals 
			for (int i = 0; i < NEXT_GENERATION_SIZE; i++) {
				Board remove = ga.population.pollFirst();
				ga.populationValue -= remove.getValue();
			}
			iterations++;
			if(numberOfSolutions < 1) {
				
			System.out.println();
			System.out.println("Best board after " + iterations + " iterations: ");
			ga.printSolution(ga.population.getLast().getBoard());
			System.out.println();
			}
			// reset algorithm if no solutions found in ITERATIONS_BEFORE_RESTART iterations
			if (iterations == ITERATIONS_BEFORE_RESTART) {
				System.out.println("failed. best value: " + ga.bestValue);
				ga.generateFirstPopulation(ga.initialBoard);
				iterations = 0;
				fails ++;
			}
		}
		//calculate time used to find solution(s)
		long totalTime =  (System.nanoTime()/ 1000000) -startTime ;
		System.out.println("Solutions found: " + numberOfSolutions);
		System.out.println("Time used: " + totalTime);
		System.out.println("fails: " + fails);
		System.out.println("avg iterations pr solution: " + ga.totalIterations/SOLUTIONS_BEFORE_STOP);
	}
}
