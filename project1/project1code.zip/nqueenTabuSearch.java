package nqueens;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

/**
 * @author Stefan Sobczyszyn Borg
 * A class to solve the n-queen problem using a tabu search algorithm
 */
public class nqueenTabuSearch {
	
	
	static int NUMBER_OF_NEIGHBOURS = 90;											// Number of neighbours in each iteration
	static int TABULIST_SIZE = 20;													// Size of tabulist
	static int SOLUTION_STOPCONDITION = 1;											// Solutions found before termination
	ArrayList<Integer> board = new ArrayList<Integer>();							// Current board representation
	ArrayList<ArrayList<Integer>> solutions = new ArrayList<ArrayList<Integer>>();	// List of unique solutions found
	Queue<Change> tabulist = new LinkedList<Change>();								// List with tabus
	private ArrayList<Integer> initialBoard;										// Initial board given by user input
	int n;																			// Size of board
	int value;																		// Objective function value of current board
	
	/**
	 * Initialize variables 
	 * 
	 * @param initialBoard		ArrayList<Integer> initial board positions
	 */
	public nqueenTabuSearch(ArrayList<Integer> initialBoard) {
		this.n = initialBoard.size();
		this.initialBoard = new ArrayList<Integer>();
		for (Integer queen : initialBoard) {
			this.initialBoard.add(queen);
		}
		this.board = generateEquilibriumBoard(initialBoard);
		this.value = calculateValue(this.board);
	}
	
	/**
	 * Calculates the fitness value of a board. The value is the sum of all attacks on each queen
	 * 
	 * @param nextBoard		arrayList<Integer board on which to calculate fitness 	
	 * @return				int value of fitness. Lower value equals higher fitness. Value = 0 is a solution
	 */
	public int calculateValue(ArrayList<Integer> nextBoard) {
		//count number of attacking queens. The higher value the worse the position on the table is
		int attacks = 0; 
		for (int i = 0; i < nextBoard.size(); i++) {
			attacks += countAttacksForQueenIn(nextBoard.get(i), i+1, nextBoard);
		}
		
		return attacks;
	}
	
	/**
	 * Help function for calculateValue(nextBoard). Calculates attacks on queen in row, row, and col, col, in board, nextBoard
	 * 
	 * @param row			int queen row
	 * @param col			int queen col
	 * @param nextBoard		arrayList<Integer board under evaluation
	 * @return				int number of attacks on queen in column, col, for column, c, c < col
	 */
	public int countAttacksForQueenIn(int row, int col, ArrayList<Integer> nextBoard) {
		int attacks = 0;
		//check earlier cols for horisontal collision
		for (int i = 1; i < col; i++) {
			if (nextBoard.get(i-1).equals(row)) {
				attacks++;
			}
		}
		//check earlier cols for diagonal (down) collision
		for (int i = col-1; i >= 1; i--)  {
			int thisRow = row+i-col;
			//check if row still on board
			//check if queen in earlier column is on the same diagonal
			if (nextBoard.get(i-1) == thisRow ) {
				attacks++;
			}
			if (thisRow < 1) {
				break;
			}
		}
		
		//check earlier cols for diagonal (up) collision
		for (int i = col-1; i >= 1; i--) {
			int thisRow = row-i+col;
			//check if row still on board
			if (nextBoard.get(i-1) == thisRow) {
				attacks++;
			}
			if (thisRow > n) {
				break;
			}
			//check if queen in earlier column is on the same diagonal
		}
		
		return attacks;
	}
	
	
	
	/**
	 * Puts one queen in each row so generateNeighbour() will work properly
	 * 
	 * @param board 		arrayList<Integer> with queen placements. Can have multiple instances of same integers
	 * @return				arrayList<Integer> with queen placements. No instances of same integers
	 */
	private ArrayList<Integer> generateEquilibriumBoard(ArrayList<Integer> board) {
		ArrayList<String> rowsNotQueened = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			int row = i + 1;
			rowsNotQueened.add(row +"");
		}
		for (int i = 0; i < n; i++) {
			
			String row = board.get(i) + "";
			if(rowsNotQueened.contains(row)) {
				rowsNotQueened.remove(row);
			} else {
				Random rdm = new Random();
				int placeInRow = rdm.nextInt(rowsNotQueened.size());
				row = rowsNotQueened.get(placeInRow);
				board.set(i, Integer.parseInt(row));
				rowsNotQueened.remove(row);
			}
			
		}

		return board;
	}

	/**
	 * Creates a list of size NUMBER_OF_NEIGBOURS with Changes to create neighbours of current board state
	 * 
	 * @return		ArrayList<Change> list with Changes which are not tabu
	 */
	private ArrayList<Change> generateNeighbours() {
		
		ArrayList<Change> neighbours = new ArrayList<Change>();
		int nrOfNeighbours = 0;
		
		
		while (nrOfNeighbours < NUMBER_OF_NEIGHBOURS) {
			//Generate a neighbour
			Change nextNeighbour = generateNeighbour();
			boolean isTabu = false;
			//if tabu list is empty neighbour is accepted
			if (tabulist.isEmpty()) {
				
			} else {
				
				for (Change tabu : tabulist) {
					// need to check if the change is tabu aswell as the change the other way because of commutativity
					if (   (  ( (nextNeighbour.getCol1() == tabu.getCol1()) || (nextNeighbour.getCol2() == tabu.getCol1()) ) && 
							( (nextNeighbour.getCol1() == tabu.getCol2()) || (nextNeighbour.getCol2() == tabu.getCol2()) )  )  
							&& (  ( (nextNeighbour.getRow1() == tabu.getRow1()) || (nextNeighbour.getRow2() != tabu.getRow1()) ) &&
							( (nextNeighbour.getRow1() == tabu.getRow2()) || (nextNeighbour.getRow2() == tabu.getRow2()) )  )   ) {
						isTabu = true;
						break;
						
					} else {
					}
				}
			}
			if (!isTabu) {
				neighbours.add(nextNeighbour);
				nrOfNeighbours++;
			}
		}
		return neighbours;
	}
	
	/**
	 * Help function for generateNeighbours. Generates a single Change
	 * 
	 * @return		a Change with information on which queen to switch 
	 */
	private Change generateNeighbour() {
		// switches a queen from a random column with another queen from a random column
		Random rdm = new Random();
		int col1 = rdm.nextInt(n);
		boolean otherColFound = false;
		while(!otherColFound) {
			int col2 = rdm.nextInt(n);
			if (col2 != col1) {
				return new Change(col1+1,board.get(col1),col2+1, board.get(col2));
			}
		}
		return null;
	}

	/**
	 * Updates tabu list.
	 * 
	 * @param change	Change to be added to tabu list
	 */
	private void updateTabuList(Change change) {
		// check if tabu list is full
		if (this.tabulist.size() > TABULIST_SIZE) {
			this.tabulist.poll();
		}
		// add next tabu
		this.tabulist.add(change);
		
	}
	
	/**
	 * Check whether current solution has been found previously
	 * 
	 * @return		boolean, true of current solution is unique. False if current solution is not unique
	 */
	private boolean checkForUniqueSolution() {
			if (!this.solutions.contains(this.board)) {
				return true;
			}
		return false;
	}
	
	/**
	 * Adds current board to solutions
	 */
	private void addSolution() {
		solutions.add(board);
		printSolution();
	}
	
	/**
	 * Prints the current positions on the board
	 */
	public void printSolution() {
		String solution = "";
		for (Integer queen : board) {
			solution += queen + " ";
		}
	System.out.println(solution);
	}

	/**
	 * Makes a change to a board. If keepChange is true it means that the change should be permanent, i.e. it is the best neighbour for the current 
	 * iteration. If keepChange is false it means that the algorithm is still looking for the best neighbour and the Change should not 
	 * be made to the main board representation, this.board. 
	 * 
	 * @param change			a Change to be made to a board
	 * @param keepChange		boolean whether the change should be made to the main board
	 * @return					a ArrayList<Integer> with the consideredBoard or null if the Change is permanent
	 */
	public ArrayList<Integer> makeChange(Change change, boolean keepChange) {
		//  Auto-generated method stub
		if (keepChange) {
			this.board.set(change.col1-1, change.row2);
			this.board.set(change.col2-1, change.row1);
		} else {
			ArrayList<Integer> consideredBoard = new ArrayList<Integer>();
			for (int i = 0; i < this.board.size(); i++) {
				consideredBoard.add(this.board.get(i));
				
			}
			consideredBoard.set(change.col1-1, change.row2);
			consideredBoard.set(change.col2-1, change.row1);
			return consideredBoard;
		}
		return null;
	}
	
	/**
	 *	Resets the algorithm back to initial input and resets variables. 
	 */
	public void resetBoard() {
		// Auto-generated method stub
		ArrayList<Integer> newBoard = new ArrayList<Integer>();
		for (Integer queen : this.initialBoard) {
			newBoard.add(queen);
		}
		newBoard = generateEquilibriumBoard(newBoard);
		value = calculateValue(newBoard);
		setBoard(newBoard,value);
		
		
	}
	
	/**
	 * Update current state 
	 * 
	 * @param newBoard		ArrayList<Integer> board to be set as current board
	 * @param value			int value of the board to be set as current board
	 */
	private void setBoard(ArrayList<Integer> newBoard, int value) {
		//  Auto-generated method stub
		this.board = newBoard;
		setValue(value);
	}

	private void setValue(int value) {
		this.value = value;
	}
	
	public static void main(String[] args) {
		//initialize the board with user input
		Scanner sc = new Scanner(System.in);
		System.out.println("size of board: ");
		int n = sc.nextInt();
		sc.nextLine();
		System.out.println("insert queen string");
		String[] board = sc.nextLine().split(" ");
		ArrayList<Integer> intBoard = new ArrayList<Integer>();
		for (String string : board) {
			intBoard.add(Integer.parseInt(string));
		}
		sc.close();
		if ((intBoard.size() != n) || intBoard.size() < 4) {
			throw new IllegalArgumentException("Wrong board size!");
		}
		
		//initialize algorithm and start clock
		nqueenTabuSearch ts = new nqueenTabuSearch(intBoard);
		int numberOfSolutions = 0;
		int iterations = 0;
		long startTime = System.nanoTime()/ 1000000;
		//algorithm start
		while(numberOfSolutions < SOLUTION_STOPCONDITION) {
			iterations++;
			//check if a solution is found
			if (ts.value == 0) {
				System.out.println("found a solution");
				
				//check for unique solution
				if(ts.checkForUniqueSolution()) {
					ts.addSolution();
					numberOfSolutions++;
					System.out.println("it was a unique one!!" + " and it was number: " + numberOfSolutions);
					ts.resetBoard();
				}
			}
			
			//generate neighbours for consideration
			ArrayList<Change> neighbour = ts.generateNeighbours();
			
			//find the neighbour, and its place in the list, with the best value
			ArrayList<Integer> values = new ArrayList<Integer>();
			int bestValue = Integer.MAX_VALUE;
			int placeWithBestValue = 0;
			for (int i = 0; i < neighbour.size(); i++) {
				ArrayList<Integer>  consideredBoard = ts.makeChange(neighbour.get(i), false);
				int value = ts.calculateValue(consideredBoard);
				values.add(value);
				if (value < bestValue) {
					bestValue = value;
					placeWithBestValue = i;
				}
				//some randomness if states have equal value
				else if (value == bestValue) {
					if (Math.random() < 0.5) {
						placeWithBestValue = i;
					}
				}
			}
			// Update the tabu list and make the change
			ts.updateTabuList(neighbour.get(placeWithBestValue));
			ts.makeChange(neighbour.get(placeWithBestValue), true);
			ts.value = values.get(placeWithBestValue);
//			System.out.println(ts.board);
			if (numberOfSolutions < 1) {
				System.out.println();
				System.out.println("Best board (value " + ts.value + ") after " + iterations + " iterations: ");
				ts.printSolution();
				
				System.out.println();
			}
		}
		//print total time used to find solution(s)
		long totalTime =  (System.nanoTime()/ 1000000) -startTime ;
		System.out.println(totalTime);
	}
}
